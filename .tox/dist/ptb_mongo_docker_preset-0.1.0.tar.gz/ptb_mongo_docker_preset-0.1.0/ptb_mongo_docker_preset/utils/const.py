from enum import Enum


class Commands(Enum):
    start = "start"
    help = "help"
