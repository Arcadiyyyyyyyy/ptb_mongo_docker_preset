def perhaps():
    return 1
